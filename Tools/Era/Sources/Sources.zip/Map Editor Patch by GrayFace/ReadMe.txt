RSPak - modules and components package

Hi all,
Although this document and demos aren't any serious, the package itself is big 
and useful. Maybe, at some point, I'll create a Help, but 'till then look for 
classes and functions in the modules, especially in RSSysUtils, RSUtils, 
RSGraphics, RSStrUtils. Some of components them were changed slightly, some were 
changed a lot.

The package was tested with Delphi 7 and a bit with Delphi 2006. If you make it 
work under another Delphi version, send it to me. All modules, excepting 
RSTimer, are to made work under Windows only.

Rozhenko Sergey aka GrayFace aka sergroj
sergroj@mail.ru