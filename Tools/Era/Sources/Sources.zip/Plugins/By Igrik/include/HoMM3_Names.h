#pragma once

// �������� ������ �� � ������
#define box64x30Pcx (*(char**)0x5D5D68) // "Box64x30.pcx"
#define iOkayDef (*(char**)0x65F4CC) // "iOkay.def"
#define iCancelDef (*(char**)0x65F4D0) // "iCancel.def"
#define artifactDef (*(char**)0x65F4D8) // "artifact.def"
#define spellsDef (*(char**)0x65F4DC) // "spells.def"
#define pskillDef (*(char**)0x65F4E4) // "pskill.def"
#define sskillDef (*(char**)0x65F4EC) // "sskill.def"
#define twcrportDef (*(char**)0x65F4E8) // "twcrport.def"
#define o_Twrport (*(char**)0x46CB5C)   // "twcrport.def"
#define cprsmallDef (*(char**)0x65F504) // "cprsmall.def"
#define adRollvrPcx (*(char**)0x401F03) // "AdRollvr.pcx"